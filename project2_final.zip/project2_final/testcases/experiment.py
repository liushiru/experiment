import os 
import timeit

def fileCompare(fileName1, fileName2):
    file1 = open(fileName1,"r")
    file2 = open(fileName2,"r")
    isSimilar = True

    for l1, l2 in zip(file1, file2):
        if not l1==l2:
            isSimilar = False
            break
    file1.close()
    file2.close()
    return isSimilar

def timeTest(difficulty):
    solutionFileName = "compare.txt"
    totalTime = 0
    for i in range(100):
        # reset solution file
        file = open(solutionFileName,"w")
        file.close()
        
        inputFileName = "input_" + difficulty + "_" + str(i+1) + ".txt"
        outputFileName = "output_" + difficulty + "_" + str(i+1) + ".txt"
        
        #cmd = "python ..\mrv.py " + inputFileName + " " + solutionFileName
        cmd = "python ..\mrv_mcv.py " + inputFileName + " " + solutionFileName
        
        start = timeit.default_timer()
        os.system(cmd)
        stop = timeit.default_timer()
        totalTime += stop - start
        if (not fileCompare(solutionFileName, outputFileName)):
            print("Error - Sudoku Solver Failing!!!")
            print("File Name - " + inputFileName)
    
    print("Total time taken to run " + difficulty + " puzzles - " + str(totalTime))
    avgTime = totalTime / 100.0
    print("Average time taken to run " + difficulty + " puzzles - " + str(avgTime) + "\n")
    return totalTime

print("Running easy puzzles")
totalTimeEasy = timeTest("easy")

print("Running intermediate puzzles")
totalTimeIntermediate = timeTest("intermediate")

print("Running hard puzzles")
totalTimeHard = timeTest("hard")

print("Running advance puzzles")
totalTimeAdvance = timeTest("advance")

totalTime = totalTimeEasy + totalTimeIntermediate + totalTimeHard + totalTimeAdvance

print("Total time taken to run all puzzles - " + str(totalTime))
avgTime = totalTime / 400.0
print("Average time taken to run all puzzles - " + str(avgTime))