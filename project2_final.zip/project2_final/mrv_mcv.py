import sys
import copy
import timeit

# Running script: given code can be run with the command:
# python file.py, ./path/to/init_state.txt ./output/output.txt

class Sudoku(object):
    def __init__(self, puzzle):
        # you may add more attributes if you need
        self.LEN = 9
        self.puzzle = puzzle # self.puzzle is a list of lists
        self.ans = copy.deepcopy(puzzle) # self.ans is a list of lists

    def solve(self):
        # TODO: Write your code here
        start = timeit.default_timer()

        initialDomainValue = int('111111111', 2) # rightmost bit for 1 and leftmost bit for 9
        domainValues = [initialDomainValue] * 81
        domainSize = [9] * 81
        numEmptyCells = 0
        constraintValue = [20] * 81

        for i in range(self.LEN):
            for j in range(self.LEN):
                if (self.puzzle[i][j] == 0):
                    numEmptyCells += 1
                # update domain values
                else:
                    # no return as puzzle is guaranteed to be solvable and there will not be conflicts at the start
                    self.forwardChecking(domainValues, domainSize, i, j)
                    self.reduceConstraintValue(constraintValue, i, j)

        self.nakedTriplet(domainValues, domainSize)

        self.backtrack(domainValues, domainSize, numEmptyCells, constraintValue)
        self.ans = copy.deepcopy(puzzle)

        stop = timeit.default_timer()
        #print('Time: ' + str(stop - start)) 

        return self.ans

    def backtrack(self, domainValues, domainSize, numEmptyCells, constraintValue):
        # return if solution is found
        found = False
        if (numEmptyCells == 0):
            if (self.isComplete()):
                return True
            else:
                return False

        # selecting unassigned variable
        # minimum-remaining-values (MRV) and most-constraining-variable (MCV) heuristic
        var = (0,0)
        minSize = 10
        minIndex = 0
        for i in range(len(domainSize)):
            row = i / 9
            col = i % 9
            if (self.puzzle[row][col] == 0):
                if (domainSize[i] < minSize):
                    var = (row,col)
                    minSize = domainSize[i]
                    minIndex = i
                elif (domainSize[i] == minSize):
                    if (constraintValue[i] > constraintValue[minIndex]):
                        var = (row,col)
                        minIndex = i

        # going through all domain values of var
        index = var[0] * 9 + var[1]
        domain = domainValues[index]

        for i in range(9):
            if (self.isBitPosSet(domain, i)): 
                tempDomainValues = domainValues[:]
                tempDomainSize = domainSize[:]
                tempConstraintValue = constraintValue[:]
                if (self.isValid(i + 1, var[0], var[1])):
                    self.puzzle[var[0]][var[1]] = i + 1

                    # update domain values / execute INFERENCE
                    # forward checking inference
                    noEmptyDomains = self.forwardChecking(tempDomainValues, tempDomainSize, var[0], var[1])
                    # if there are cells with empty domains, reset changed values and return continue
                    if (not noEmptyDomains):
                        self.puzzle[var[0]][var[1]] = 0
                        continue

                    self.reduceConstraintValue(tempConstraintValue, var[0], var[1])

                    # recursively search for solution
                    found = self.backtrack(tempDomainValues, tempDomainSize, numEmptyCells-1, tempConstraintValue)
                    if found:
                        return True
                    else:
                        # reset changed values if no solution was found
                        self.puzzle[var[0]][var[1]] = 0

        return False

    # to update domain values and domain size
    # return False if there exist 1 cell with no more domain values
    def nakedTriplet(self, domainValues, domainSize):
        # loop through entire puzzle -> if domain size <= 3, check naked triplets and pairs
        for i in range(self.LEN):
            for j in range(self.LEN):
                index = i * 9 + j
                if (self.puzzle[i][j] == 0 and domainSize[index] <= 3 and domainSize[index] >= 2):
                    # check naked triplets and pairs
                    numRemainingValues = self.getNumOnesInBit(domainValues[index]);

                    # check row
                    numCandidates = 0
                    candidateList = []
                    for k in range(self.LEN):
                        if (self.puzzle[i][k] == 0):
                            # check if they contain other values besides those of domainValues[index]
                            otherValuesBitCheck = ~domainValues[index] & domainValues[i * 9 + k]
                            numOnes = self.getNumOnesInBit(otherValuesBitCheck)
                            if (numOnes <= 0):
                                candidateList.append(k)
                                numCandidates += 1
                    # if naked triplets or pairs exist, remove these values from row
                    if (numCandidates >= numRemainingValues):
                        valuesToRemove = ~domainValues[index]
                        for k in range(self.LEN):
                            if (k not in candidateList):
                                domainValues[i * 9 + k] &= valuesToRemove
                                domainSize[i * 9 + k] = self.getNumOnesInBit(domainValues[i * 9 + k]);
                                if (not domainSize[i * 9 + k] ^ 0):
                                    return False

                    # check column
                    numCandidates = 0
                    candidateList = []
                    for k in range(self.LEN):
                        if (self.puzzle[k][j] == 0):
                            otherValuesBitCheck = ~domainValues[index] & domainValues[k * 9 + j]
                            numOnes = self.getNumOnesInBit(otherValuesBitCheck)
                            if (numOnes <= 0):
                                candidateList.append(k)
                                numCandidates += 1
                    # if naked triplets or pairs exist, remove these values from column
                    if (numCandidates >= numRemainingValues):
                        valuesToRemove = ~domainValues[index]
                        for k in range(self.LEN):
                            if (k not in candidateList):
                                domainValues[k * 9 + j] &= valuesToRemove
                                domainSize[k * 9 + j] = self.getNumOnesInBit(domainValues[k * 9 + j])
                                if (not domainSize[k * 9 + j] ^ 0):
                                    return False

                    # check box
                    numCandidates = 0
                    candidateList = []
                    rowIdx = i // 3
                    colIdx = j // 3
                    for k in range(rowIdx*3, rowIdx*3 + 3):
                        for l in range(colIdx * 3, colIdx*3 + 3):
                            compareIdx = k * 9 + l
                            if (self.puzzle[k][l] == 0):
                                otherValuesBitCheck = ~domainValues[index] & domainValues[compareIdx]
                                numOnes = self.getNumOnesInBit(otherValuesBitCheck)
                                if (numOnes <= 0):
                                    candidateList.append(compareIdx)
                                    numCandidates += 1
                    # if naked triplets or pairs exist, remove these values from box
                    if (numCandidates >= numRemainingValues):
                        valuesToRemove = ~domainValues[index]
                        for k in range(rowIdx*3, rowIdx*3 + 3):
                            for l in range(colIdx * 3, colIdx*3 + 3):
                                compareIdx = k * 9 + l
                                if (compareIdx not in candidateList):
                                    domainValues[compareIdx] &= valuesToRemove
                                    domainSize[compareIdx] = self.getNumOnesInBit(domainValues[compareIdx])
                                    if (not domainSize[compareIdx] ^ 0):
                                        return False
        return True

    # to update domain values and domain size
    # return False if there exist 1 cell with no more domain values
    def forwardChecking(self, domainValues, domainSize, row, col):
        valueToRemove = self.puzzle[row][col]

        # update row
        for i in range(self.LEN):
            index = row * 9 + i
            if (not i == col and self.isBitPosSet(domainValues[index], valueToRemove-1)):
                domainValues[index] = domainValues[index] & ~(1 << (valueToRemove-1))
                domainSize[index] -= 1
                if (not domainSize[index] ^ 0):
                    return False

        # update column
        for i in range(self.LEN):
            index = i * 9 + col
            if (not i == row and self.isBitPosSet(domainValues[index], valueToRemove-1)):
                domainValues[index] = domainValues[index] & ~(1 << (valueToRemove-1))
                domainSize[index] -= 1
                if (not domainSize[index] ^ 0):
                    return False

        # update box
        rowIdx = row // 3
        colIdx = col // 3
        for i in range(rowIdx*3, rowIdx*3 + 3):
            for j in range(colIdx * 3, colIdx*3 + 3):
                index = i * 9 + j
                if (not i == row and not j == col and self.isBitPosSet(domainValues[index], valueToRemove-1)):
                    domainValues[index] = domainValues[index] & ~(1 << (valueToRemove-1))
                    domainSize[index] -= 1
                    if (not domainSize[index] ^ 0):
                        return False
        return True

    # reduce constraint value of neighbours after a value is assigned
    def reduceConstraintValue(self, constraintValue, row, col):
        # update row
        for i in range(9):
            index = row * 9 + i
            #if (not i == col and self.puzzle[row][i] == 0):
            if (not i == col):
                constraintValue[index] -= 1
        
        # update column
        for i in range(9):
            index = i * 9 + col
            #if (not i == row and self.puzzle[i][col] == 0):
            if (not i == row):
                constraintValue[index] -= 1
            
        # update box
        rowIdx = row // 3
        colIdx = col // 3
        for i in range(rowIdx*3, rowIdx*3 + 3):
            for j in range(colIdx * 3, colIdx*3 + 3):
                index = i * 9 + j
                #if (not i == row and not j == col and self.puzzle[i][j] == 0):
                if (not i == row and not j == col):
                    constraintValue[index] -= 1

    def isBitPosSet(self, val, pos):
        newVal = val >> pos
        return (newVal & 1)

    def bitLen(self, val):
        length = 0
        while (val):
            val >>= 1
            length += 1
        return length

    # get number of 1 in binary int
    def getNumOnesInBit(self, value):
        count = 0
        while (value): 
            if (value & 1):
                count += 1
            value >>= 1
        return count 

    def isValid(self, num, row, col):
        # check row
        if num in self.puzzle[row]:
            return False

        # check column
        for i in range(self.LEN):
            if (self.puzzle[i][col] == num):
                return False

        # check box
        rowIdx = row // 3
        colIdx = col // 3
        for i in range(rowIdx*3, rowIdx*3 + 3):
            for j in range(colIdx * 3, colIdx*3 + 3):
                if (self.puzzle[i][j] == num):
                    return False
        return True

    def isComplete(self):
        for i in range(self.LEN):
            if 0 in self.puzzle[i]:
                return False

        # check correctness of row
        for i in range(self.LEN):
            tracker = [False] * 10  # reset tracker every row
            for j in range(self.LEN):
                if not tracker[self.puzzle[i][j]]:
                    tracker[self.puzzle[i][j]] = True;
                else:
                    return False;

        # check correctness of column
        for i in range(self.LEN):
            tracker = [False] * 10  # reset tracker every column
            for j in range(self.LEN):
                if not tracker[self.puzzle[j][i]]:
                    tracker[self.puzzle[j][i]] = True
                else:
                    return False

        # check correctness of box
        for i in range(3):
            for j in range(3):
                tracker = [False] * 10  # reset tracker every box
                for k in range(3):
                    for l in range(3):
                        if not tracker[self.puzzle[(i * 3) + k][(j * 3) + l]]:
                            tracker[self.puzzle[(i * 3) + k][(j * 3) + l]] = True
                        else:
                            return False
        return True

    # you may add more classes/functions if you think is useful
    # However, ensure all the classes/functions are in this file ONLY
    # Note that our evaluation scripts only call the solve method.
    # Any other methods that you write should be used within the solve() method.

if __name__ == "__main__":
    # STRICTLY do NOT modify the code in the main function here
    if len(sys.argv) != 3:
        print ("\nUsage: python CS3243_P2_Sudoku_XX.py input.txt output.txt\n")
        raise ValueError("Wrong number of arguments!")

    try:
        f = open(sys.argv[1], 'r')
    except IOError:
        print ("\nUsage: python CS3243_P2_Sudoku_XX.py input.txt output.txt\n")
        raise IOError("Input file not found!")

    puzzle = [[0 for i in range(9)] for j in range(9)]
    lines = f.readlines()

    i, j = 0, 0
    for line in lines:
        for number in line:
            if '0' <= number <= '9':
                puzzle[i][j] = int(number)
                j += 1
                if j == 9:
                    i += 1
                    j = 0

    sudoku = Sudoku(puzzle)
    ans = sudoku.solve()

    with open(sys.argv[2], 'a') as f:
        for i in range(9):
            for j in range(9):
                f.write(str(ans[i][j]) + " ")
            f.write("\n")